 php artisan make:controller SkillController --resource --model=Skill
